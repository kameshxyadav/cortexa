# DECISIONS — one line each (date · decision · reason)

- Stack fixed per SPEC §3 (Next.js + FastAPI + SQLite + Chroma). Reason: portable, no infra, resumable across accounts.
- LLM calls go through a disk-cached client (LLM_MODE=cache). Reason: save credits, deterministic demo.
- Demo corpus: Operating Systems (CPU scheduling + memory management). Reason: diagrams + numerical problems.
- Mastery model: BKT with evidence weights. Reason: interpretable, easy to simulate and explain.
