# StudyMate

Source-grounded, adaptive AI study companion (Multimodal AI Hackathon 2026, Track D).

**Building this with Antigravity?** Open `AGENTS.md` first, then `docs/PROGRESS.md`.
Moving to another account? See `docs/HANDOFF.md`.

(Replace this file with the real README during milestone M9.)
