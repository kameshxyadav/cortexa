#!/usr/bin/env bash
# Creates a portable backup zip (keeps llm_cache and demo processed data).
set -e
NAME="studymate-backup-$(date +%Y%m%d-%H%M).zip"
cd "$(dirname "$0")/.."
zip -r "../$NAME" . \
  -x "node_modules/*" "*/node_modules/*" ".venv/*" "*/.venv/*" \
     ".next/*" "*/.next/*" "__pycache__/*" "*/__pycache__/*" \
     ".env" "data/app.db" "data/chroma/*" ".git/*"
echo "Created ../$NAME  (git history excluded; push to GitHub for full history)"
